package com.packt.thimblerig.domain;

import org.springframework.stereotype.Component;

@Component
class RandomNumberGenerator {
  public int getRandomInt() {
    return 3;
  }
}
