package com.packt.thimblerig.api.dto;

public class Error {
  public final String reason;

  public Error(String reason) {
    this.reason = reason;
  }
}
